#!/usr/bin/env python3
import sys
import os
import subprocess
import re
from gi.repository import Gtk, Gio, GLib

APP_ID = "com.bettertext.BetterText"
APP_NAME = "BetterText"

URL_RE = re.compile(r"^https?://", re.IGNORECASE)

class BetterTextApp(Gtk.Application):
    def __init__(self):
        super().__init__(application_id=APP_ID, flags=Gio.ApplicationFlags.HANDLES_OPEN)
        self.window = None

    def do_activate(self):
        if not self.window:
            self.window = MainWindow(self)
        self.window.present()

    def do_open(self, files, n_files, hint):
        if not self.window:
            self.window = MainWindow(self)
        if files:
            self.window.open_path(files[0].get_path())
        self.window.present()

class MainWindow(Gtk.ApplicationWindow):
    def __init__(self, app):
        super().__init__(application=app)
        self.set_title(APP_NAME)
        self.set_default_size(900, 700)
        self.current_path = None

        header = Gtk.HeaderBar(title=APP_NAME)
        header.set_show_close_button(True)
        self.set_titlebar(header)

        open_btn = Gtk.Button.new_with_label("Open")
        open_btn.connect("clicked", self.on_open_clicked)
        header.pack_start(open_btn)

        save_btn = Gtk.Button.new_with_label("Save As")
        save_btn.connect("clicked", self.on_save_clicked)
        header.pack_end(save_btn)

        self.textview = Gtk.TextView()
        self.textview.set_wrap_mode(Gtk.WrapMode.WORD)
        self.buffer = self.textview.get_buffer()

        scroller = Gtk.ScrolledWindow()
        scroller.add(self.textview)
        self.add(scroller)

    def set_text(self, text):
        self.buffer.set_text(text)

    def get_text(self):
        start, end = self.buffer.get_bounds()
        return self.buffer.get_text(start, end, True)

    def open_path(self, path):
        if not path:
            return
        if URL_RE.match(path):
            try:
                result = subprocess.run(["curl", "-L", "-s", path], check=True, capture_output=True, text=True)
                self.set_text(result.stdout)
                self.current_path = path
                self.set_title(f"{APP_NAME} - {path}")
                return
            except Exception as e:
                self.show_error(f"Failed to fetch URL:\n{e}")
                return

        try:
            with open(path, "r", encoding="utf-8", errors="replace") as f:
                self.set_text(f.read())
            self.current_path = path
            self.set_title(f"{APP_NAME} - {path}")
        except Exception as e:
            self.show_error(f"Failed to open file:\n{e}")

    def on_open_clicked(self, _btn):
        dialog = Gtk.FileChooserDialog(
            title="Open File",
            parent=self,
            action=Gtk.FileChooserAction.OPEN,
        )
        dialog.add_buttons(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, Gtk.STOCK_OPEN, Gtk.ResponseType.OK)
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            self.open_path(dialog.get_filename())
        dialog.destroy()

    def on_save_clicked(self, _btn):
        dialog = Gtk.FileChooserDialog(
            title="Save File",
            parent=self,
            action=Gtk.FileChooserAction.SAVE,
        )
        dialog.set_do_overwrite_confirmation(True)
        dialog.add_buttons(Gtk.STOCK_CANCEL, Gtk.ResponseType.CANCEL, Gtk.STOCK_SAVE, Gtk.ResponseType.OK)
        response = dialog.run()
        if response == Gtk.ResponseType.OK:
            path = dialog.get_filename()
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(self.get_text())
                self.current_path = path
                self.set_title(f"{APP_NAME} - {path}")
            except Exception as e:
                self.show_error(f"Failed to save file:\n{e}")
        dialog.destroy()

    def show_error(self, message):
        md = Gtk.MessageDialog(self, 0, Gtk.MessageType.ERROR, Gtk.ButtonsType.OK, APP_NAME)
        md.format_secondary_text(message)
        md.run()
        md.destroy()


def main():
    app = BetterTextApp()

    # If a file path is passed directly, forward it to the app open handler
    if len(sys.argv) > 1:
        # Gio.Application handles files; use a temporary file list
        file = Gio.File.new_for_path(sys.argv[1])
        app.register(None)
        app.open([file], "")
        app.run([])
    else:
        app.run(sys.argv)


if __name__ == "__main__":
    main()
